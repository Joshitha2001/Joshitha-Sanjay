package com.Carbonemission_BE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarbonemissionBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarbonemissionBeApplication.class, args);
	}

}
