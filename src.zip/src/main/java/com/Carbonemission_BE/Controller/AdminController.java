package com.Carbonemission_BE.Controller;

import com.Carbonemission_BE.Entity.Admin;
import com.Carbonemission_BE.Repository.AdminRepo;
import com.Carbonemission_BE.Service.GeminiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@CrossOrigin("*")
public class AdminController {

    @Autowired
    private AdminRepo adminRepo;

    private final GeminiService geminiService;

    public AdminController(GeminiService geminiService) {
        this.geminiService = geminiService;
    }

    @PutMapping("/updatepassword/{newpwd}/{email}")
    public ResponseEntity<?> updatepassword(@RequestBody Admin obj, @PathVariable String newpwd, @PathVariable String email)
    {
        var admin=adminRepo.findByEmail(email).orElseThrow(()->new RuntimeException("Not found"));
        if(admin.getPassword().equals(obj.getPassword()))
        {
            admin.setPassword(newpwd);
            adminRepo.save(admin);

            return new ResponseEntity<>("Password update successfully", HttpStatus.OK);
        }
        else
        {
            throw new RuntimeException("Invalid Old Password");
        }

    }

    @GetMapping("/test-models")
    public void testModels() {
        geminiService.printAvailableModels();
    }


    @PutMapping("/UpdateAdminByEmail/{email}")
    public ResponseEntity<?> updateAdminByEmail(
            @PathVariable String email,
            @RequestBody Admin updatedAdmin) {

        Optional<Admin> optionalAdmin = adminRepo.findByEmail(email);

        if (optionalAdmin.isEmpty()) {
            return new ResponseEntity<>("Admin not found with email: " + email, HttpStatus.NOT_FOUND);
        }

        Admin existingAdmin = optionalAdmin.get();

        // Update fields
        existingAdmin.setPassword(updatedAdmin.getPassword());
        // If you later add fields like name, role, etc., update those too.

        adminRepo.save(existingAdmin);

        return new ResponseEntity<>("Admin updated successfully", HttpStatus.OK);
    }



}
