package com.Carbonemission_BE.Controller;

import com.Carbonemission_BE.Entity.CarbonDetails;
import com.Carbonemission_BE.Entity.User;
import com.Carbonemission_BE.Repository.CarbonDetailsRepo;
import com.Carbonemission_BE.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@CrossOrigin("*")
public class CarbonDetailsController {

    @Autowired
    private CarbonDetailsRepo carbonDetailsRepo;

    @Autowired
    private UserRepo userRepo;

    @GetMapping("/user/{userId}/monthly-carbon-summary")
    public ResponseEntity<?> getMonthlyCarbonSummary(@PathVariable Integer userId) {

        // Check user exists
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Fetch carbon details
        List<CarbonDetails> detailsList =
                carbonDetailsRepo.findByUserIdOrderByDateAsc(userId);

        if (detailsList.isEmpty()) {
            return ResponseEntity.ok("No carbon data available for this user");
        }

        // Group by YearMonth
        Map<YearMonth, List<CarbonDetails>> groupedByMonth =
                detailsList.stream()
                        .filter(cd -> cd.getDate() != null)
                        .filter(cd -> cd.getCarbonEmission() != null)
                        .collect(Collectors.groupingBy(
                                cd -> YearMonth.from(cd.getDate()),
                                LinkedHashMap::new,
                                Collectors.toList()
                        ));


        List<Map<String, Object>> monthlySummary = new ArrayList<>();
        List<Integer> monthlyTotals = new ArrayList<>();

        for (Map.Entry<YearMonth, List<CarbonDetails>> entry : groupedByMonth.entrySet()) {

            int monthlySum = entry.getValue()
                    .stream()
                    .mapToInt(cd -> cd.getCarbonEmission() == null ? 0 : cd.getCarbonEmission())
                    .sum();

            monthlyTotals.add(monthlySum);

            Map<String, Object> monthData = new HashMap<>();
            monthData.put("month", entry.getKey().toString()); // 2025-01
            monthData.put("totalCarbonEmission", monthlySum);

            monthlySummary.add(monthData);
        }

        // Calculate average
        double average =
                monthlyTotals.stream().mapToInt(Integer::intValue).average().orElse(0);

        // Simple next month prediction (average-based)
        int nextMonthPrediction = (int) Math.round(average);

        // Final response
        Map<String, Object> response = new HashMap<>();
        response.put("userId", userId);
        response.put("monthlySummary", monthlySummary);
        response.put("monthlyAverage", average);
        response.put("nextMonthPrediction", nextMonthPrediction);

        return ResponseEntity.ok(response);
    }


    @PostMapping("/AddCarbondetails/{id}")
    public ResponseEntity<?> AddCarbondetails(@RequestBody CarbonDetails obj, @PathVariable Integer id) {
        var users = userRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("userid not found"));
        obj.setUser(users);
        carbonDetailsRepo.save(obj);
        return new ResponseEntity<>("Added successfully", HttpStatus.OK);
    }

    @PutMapping("/UpdateCarbondetails/{id}")
    public ResponseEntity<?> updateCarbonDetailsFull(@RequestBody CarbonDetails obj, @PathVariable Integer id) {

        CarbonDetails existing = carbonDetailsRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("CarbonDetails not found"));

        existing.setDate(obj.getDate());
        existing.setHeatingEnergySource(obj.getHeatingEnergySource());
        existing.setTransport(obj.getTransport());
        existing.setVehicleType(obj.getVehicleType());
        existing.setSocialActivity(obj.getSocialActivity());
        existing.setGroceryBill(obj.getGroceryBill());
        existing.setVehicleDistanceKm(obj.getVehicleDistanceKm());
        existing.setWasteBagSize(obj.getWasteBagSize());
        existing.setWasteBagCount(obj.getWasteBagCount());
        existing.setTvPcDailyHour(obj.getTvPcDailyHour());
        existing.setNewClothes(obj.getNewClothes());
        existing.setInternetDailyHour(obj.getInternetDailyHour());
        existing.setEnergyEfficiency(obj.getEnergyEfficiency());
        existing.setRecycling(obj.getRecycling());
        existing.setCookingWith(obj.getCookingWith());
        existing.setCarbonEmission(obj.getCarbonEmission());

        // keep user same (or update if you want)
        existing.setUser(existing.getUser());

        carbonDetailsRepo.save(existing);
        return ResponseEntity.ok("Updated successfully");
    }


    @GetMapping("/GetCarbonDetails")
    public ResponseEntity<?> GetCarbonDetails(){
        var areas=carbonDetailsRepo.findAll();
        return new ResponseEntity<>(areas,HttpStatus.OK);
    }

    @GetMapping("/GetCarbonDetailsbyuserid/{id}")
    public ResponseEntity<?> GetCarbonDetailsbyuserid(@PathVariable Integer id){
        var areas=carbonDetailsRepo.findByUserId(id);
        return new ResponseEntity<>(areas,HttpStatus.OK);
    }

    @GetMapping("/GetCarbonDetailsPreviousMonth/{id}")
    public ResponseEntity<?> getCarbonDetailsPreviousMonth(@PathVariable Integer id) {
        // Get current date
        LocalDate currentDate = LocalDate.now();

        // Get previous month
        YearMonth previousMonth = YearMonth.from(currentDate.minusMonths(1));

        // Get first and last day of previous month
        LocalDate startDate = previousMonth.atDay(1);
        LocalDate endDate = previousMonth.atEndOfMonth();

        // Query database for records in that date range for the user
        List<CarbonDetails> previousMonthRecords = carbonDetailsRepo
                .findByUserIdAndDateBetween(id, startDate, endDate);

        return new ResponseEntity<>(previousMonthRecords, HttpStatus.OK);
    }

    @GetMapping("/carbon/GetCarbonDetailsCurrentMonth/{id}")
    public ResponseEntity<?> getCarbonDetailsCurrentMonth(@PathVariable Integer id) {

        // Get current date
        LocalDate currentDate = LocalDate.now();

        // Get current month
        YearMonth currentMonth = YearMonth.from(currentDate);

        // Get first and last day of current month
        LocalDate startDate = currentMonth.atDay(1);
        LocalDate endDate = currentMonth.atEndOfMonth();

        // Query database for records in that date range for the user
        List<CarbonDetails> currentMonthRecords = carbonDetailsRepo
                .findByUserIdAndDateBetween(id, startDate, endDate);

        return new ResponseEntity<>(currentMonthRecords, HttpStatus.OK);
    }


    @GetMapping("/carb/CurrentMonthTotals/users")
    public ResponseEntity<?> getCurrentMonthTotals() {

        LocalDate today = LocalDate.now();

        List<Object[]> results = carbonDetailsRepo.getTotalCarbonEmissionForCurrentMonth(today);

        List<Map<String, Object>> response = new ArrayList<>();

        for (Object[] obj : results) {

            Integer userId = (Integer) obj[0];
            Long totalEmission = (Long) obj[1];  // because SUM returns Long

            userRepo.findById(userId).ifPresent(user -> {
                Map<String, Object> map = new HashMap<>();
                map.put("userId", user.getId());
                map.put("userName", user.getName());
                map.put("email", user.getEmail());
                map.put("totalEmission", totalEmission);
                response.add(map);
            });
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


}
