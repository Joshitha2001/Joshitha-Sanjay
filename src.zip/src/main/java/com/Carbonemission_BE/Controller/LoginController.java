package com.Carbonemission_BE.Controller;

import com.Carbonemission_BE.DTO.LoginDto;
import com.Carbonemission_BE.Repository.AdminRepo;
import com.Carbonemission_BE.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class LoginController {

    @Autowired
    private AdminRepo adminRepo;

    @Autowired
    private UserRepo usersRepo;

    @PostMapping("/LoginVerify")
    public ResponseEntity<?> LoginVerify(@RequestBody LoginDto obj){
        if(obj.getUsertype().equals("Admin")){
            var users = adminRepo.findByEmail(obj.getEmail())
                    .orElseThrow(() -> new RuntimeException("email not found"));

            if(users.getPassword().equals(obj.getPassword())){
                // Return admin info as JSON
                Map<String, Object> response = new HashMap<>();
                response.put("usertype", "Admin");
                response.put("user", users);
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                throw new RuntimeException("invalid password");
            }
        }

        else if(obj.getUsertype().equals("User")){
            var users = usersRepo.findByEmail(obj.getEmail())
                    .orElseThrow(() -> new RuntimeException("email not found"));

            if(users.getPassword().equals(obj.getPassword())){
                // Return user info as JSON
                Map<String, Object> response = new HashMap<>();
                response.put("usertype", "User");
                response.put("user", users);
                return new ResponseEntity<>(response, HttpStatus.OK);
            } else {
                throw new RuntimeException("invalid password");
            }
        }

        else {
            throw new RuntimeException("usertype not found");
        }
    }
}

