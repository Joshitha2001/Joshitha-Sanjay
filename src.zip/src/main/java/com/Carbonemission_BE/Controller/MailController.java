package com.Carbonemission_BE.Controller;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class MailController {

    @Value("${google.api.key}")
    private String apiKey;

    @Autowired
    private JavaMailSender mailSender;

    // -----------------------------
    //  POST: Send Emission Email
    // -----------------------------
    @PostMapping("/mail/sendEmissionSuggestion")
    public ResponseEntity<?> sendEmissionEmail(@RequestBody Map<String, Object> req) {

        int totalEmission = (int) req.get("totalEmission");
        String userName = (String) req.get("userName");
        String email = (String) req.get("email");

        int maxValue = 150000;
        double percent = (totalEmission * 100.0) / maxValue;

        // 🔥 Call Gemini
        String suggestions = callGeminiForSuggestions(totalEmission, percent);

        // ❌ If suggestions failed → Don't send mail
        if (suggestions == null || suggestions.isEmpty()) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Gemini could not generate suggestions. Mail NOT sent.");
        }

        // Create the email
        String subject = "Your Carbon Emission Report";

        String message =
                "Hello " + userName + ",\n\n" +
                        "Your total carbon emission this month: " + totalEmission + " CO₂e.\n" +
                        "This is " + String.format("%.2f", percent) + "% of the max (150000).\n\n" +
                        "👉 Suggestions to reduce your carbon footprint:\n\n" +
                        suggestions + "\n\n" +
                        "Regards,\nCarbon Tracker Team";

        sendEmail(email, subject, message);

        return ResponseEntity.ok("Mail Sent Successfully With Suggestions!");
    }


    // -----------------------------
    //   GEMINI API CALL (inside controller)
    // -----------------------------
    private String callGeminiForSuggestions(int emission, double percent) {
        try {
            String url =
                    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="
                            + apiKey;

            String prompt =
                    "Carbon Emission: " + emission + " CO2e\n" +
                            "Percent of 150000: " + percent + "%\n" +
                            "Give short, actionable suggestions to reduce carbon footprint. " +
                            "No introduction, only bullet points.";

            JSONObject textObj = new JSONObject();
            textObj.put("text", prompt);

            JSONArray parts = new JSONArray();
            parts.put(textObj);

            JSONObject contentObj = new JSONObject();
            contentObj.put("parts", parts);

            JSONArray contentsArray = new JSONArray();
            contentsArray.put(contentObj);

            JSONObject finalBody = new JSONObject();
            finalBody.put("contents", contentsArray);

            HttpClient client = HttpClient.newHttpClient();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(finalBody.toString()))
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            JSONObject json = new JSONObject(response.body());

            // 🚨 SAFE CHECK: if Gemini failed, return null
            if (!json.has("candidates")) {
                return null;
            }

            return json
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text");

        } catch (Exception e) {
            return null;   // ❌ Gemini failed
        }
    }


    // -----------------------------
    //   SEND EMAIL
    // -----------------------------
    private void sendEmail(String toEmail, String subject, String body) {

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(toEmail);
        msg.setSubject(subject);
        msg.setText(body);

        mailSender.send(msg);
    }
}

