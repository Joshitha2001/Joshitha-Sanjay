package com.Carbonemission_BE.Controller;

import com.Carbonemission_BE.Entity.CarbonDetails;
import com.Carbonemission_BE.Entity.User;
import com.Carbonemission_BE.Repository.UserRepo;
import com.Carbonemission_BE.Service.GeminiService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class SuggestionsController {

    private final GeminiService geminiService;
    private final UserRepo userRepo;

    public SuggestionsController(GeminiService geminiService, UserRepo userRepo) {
        this.geminiService = geminiService;
        this.userRepo = userRepo;
    }

    @GetMapping("/carbon-suggestions/{userid}")
    public Map<String, Object> getCarbonSuggestions(@PathVariable Integer userid) {

        User user = userRepo.findById(userid).orElse(null);

        List<Map<String, String>> suggestions = geminiService.getUserSuggestions(user);

        return Map.of("suggestions", suggestions);
    }

}
