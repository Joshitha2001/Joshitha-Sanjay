package com.Carbonemission_BE.Controller;

import com.Carbonemission_BE.Entity.User;
import com.Carbonemission_BE.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
@CrossOrigin("*")
public class UserController {

    @Autowired
    private UserRepo userRepo;

    @PostMapping("/AddUsers")
    public ResponseEntity<?> AddUsers(@RequestBody User obj){

        userRepo.save(obj);
        return new ResponseEntity<>("Added successfully", HttpStatus.OK);
    }

    @PutMapping("/UpdateUserByEmail/{email}")
    public ResponseEntity<?> updateUserByEmail(
            @PathVariable String email,
            @RequestBody User updatedUser) {

        Optional<User> optionalUser = userRepo.findByEmail(email);

        if (optionalUser.isEmpty()) {
            return new ResponseEntity<>("User not found with email: " + email, HttpStatus.NOT_FOUND);
        }

        User existingUser = optionalUser.get();

        // update fields
        existingUser.setName(updatedUser.getName());
        existingUser.setMobile(updatedUser.getMobile());
        existingUser.setPassword(updatedUser.getPassword());
        existingUser.setBodyType(updatedUser.getBodyType());
        existingUser.setSex(updatedUser.getSex());
        existingUser.setDiet(updatedUser.getDiet());
        existingUser.setHowOftenShower(updatedUser.getHowOftenShower());
        existingUser.setFrequencyOfTravelingByAir(updatedUser.getFrequencyOfTravelingByAir());

        userRepo.save(existingUser);

        return new ResponseEntity<>("User updated successfully", HttpStatus.OK);
    }


    @GetMapping("/GetUsers")
    public ResponseEntity<?> GetUsers(){
        var areas=userRepo.findAll();
        return new ResponseEntity<>(areas,HttpStatus.OK);
    }

    @GetMapping("/GetUsersbyEmail/{email}")
    public ResponseEntity<?> GetUsersbyEmail(@PathVariable String email){
        var data=userRepo.findByEmail(email);
        return new ResponseEntity<>(data,HttpStatus.OK);
    }

}
