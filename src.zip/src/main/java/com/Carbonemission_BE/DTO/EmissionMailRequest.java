package com.Carbonemission_BE.DTO;

public class EmissionMailRequest {

    private Integer totalEmission;
    private String userName;
    private Integer userId;
    private String email;

    public Integer getTotalEmission() {
        return totalEmission;
    }

    public void setTotalEmission(Integer totalEmission) {
        this.totalEmission = totalEmission;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
