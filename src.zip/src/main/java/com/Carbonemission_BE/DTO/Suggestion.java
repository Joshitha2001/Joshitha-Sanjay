package com.Carbonemission_BE.DTO;

public class Suggestion {
    private String suggestion;
    private String reason;
    private String estimatedImpact;

    public Suggestion(String suggestion, String reason, String estimatedImpact) {
        this.suggestion = suggestion;
        this.reason = reason;
        this.estimatedImpact = estimatedImpact;
    }

    // Getters and setters
    public String getSuggestion() { return suggestion; }
    public void setSuggestion(String suggestion) { this.suggestion = suggestion; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public String getEstimatedImpact() { return estimatedImpact; }
    public void setEstimatedImpact(String estimatedImpact) { this.estimatedImpact = estimatedImpact; }
}
