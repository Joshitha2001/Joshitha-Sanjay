package com.Carbonemission_BE.Entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity

public class CarbonDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private LocalDate date;
    private String heatingEnergySource;
    private String transport;
    private String vehicleType;
    private String socialActivity;
    private Integer groceryBill;
    private Integer VehicleDistanceKm;
    private String wasteBagSize;
    private Integer wasteBagCount;
    private Integer tvPcDailyHour;
    private Integer newClothes;
    private Integer internetDailyHour;
    private String energyEfficiency;
    private String recycling;
    private String cookingWith;
    @Column(nullable = false)
    private Integer carbonEmission;

    @ManyToOne
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getHeatingEnergySource() {
        return heatingEnergySource;
    }

    public void setHeatingEnergySource(String heatingEnergySource) {
        this.heatingEnergySource = heatingEnergySource;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getSocialActivity() {
        return socialActivity;
    }

    public void setSocialActivity(String socialActivity) {
        this.socialActivity = socialActivity;
    }

    public Integer getGroceryBill() {
        return groceryBill;
    }

    public void setGroceryBill(Integer groceryBill) {
        this.groceryBill = groceryBill;
    }

    public Integer getVehicleDistanceKm() {
        return VehicleDistanceKm;
    }

    public void setVehicleDistanceKm(Integer vehicleDistanceKm) {
        VehicleDistanceKm = vehicleDistanceKm;
    }

    public String getWasteBagSize() {
        return wasteBagSize;
    }

    public void setWasteBagSize(String wasteBagSize) {
        this.wasteBagSize = wasteBagSize;
    }

    public Integer getWasteBagCount() {
        return wasteBagCount;
    }

    public void setWasteBagCount(Integer wasteBagCount) {
        this.wasteBagCount = wasteBagCount;
    }

    public Integer getTvPcDailyHour() {
        return tvPcDailyHour;
    }

    public void setTvPcDailyHour(Integer tvPcDailyHour) {
        this.tvPcDailyHour = tvPcDailyHour;
    }

    public Integer getNewClothes() {
        return newClothes;
    }

    public void setNewClothes(Integer newClothes) {
        this.newClothes = newClothes;
    }

    public Integer getInternetDailyHour() {
        return internetDailyHour;
    }

    public void setInternetDailyHour(Integer internetDailyHour) {
        this.internetDailyHour = internetDailyHour;
    }

    public String getEnergyEfficiency() {
        return energyEfficiency;
    }

    public void setEnergyEfficiency(String energyEfficiency) {
        this.energyEfficiency = energyEfficiency;
    }

    public String getRecycling() {
        return recycling;
    }

    public void setRecycling(String recycling) {
        this.recycling = recycling;
    }

    public String getCookingWith() {
        return cookingWith;
    }

    public void setCookingWith(String cookingWith) {
        this.cookingWith = cookingWith;
    }

    public Integer getCarbonEmission() {
        return carbonEmission;
    }

    public void setCarbonEmission(Integer carbonEmission) {
        this.carbonEmission = carbonEmission;
    }
}
