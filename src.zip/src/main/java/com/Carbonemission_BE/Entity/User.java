package com.Carbonemission_BE.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String mobile;
    private String email;
    private String password;
    private String bodyType;
    private String sex;
    private String diet;
    private String howOftenShower;
    private String frequencyOfTravelingByAir;

    @OneToMany(mappedBy = "user")
    @JsonIgnore
    List<CarbonDetails> carbonDetails;

    public List<CarbonDetails> getCarbonDetails() {
        return carbonDetails;
    }

    public void setCarbonDetails(List<CarbonDetails> carbonDetails) {
        this.carbonDetails = carbonDetails;
    }

    public String getBodyType() {
        return bodyType;
    }

    public void setBodyType(String bodyType) {
        this.bodyType = bodyType;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getDiet() {
        return diet;
    }

    public void setDiet(String diet) {
        this.diet = diet;
    }

    public String getHowOftenShower() {
        return howOftenShower;
    }

    public void setHowOftenShower(String howOftenShower) {
        this.howOftenShower = howOftenShower;
    }

    public String getFrequencyOfTravelingByAir() {
        return frequencyOfTravelingByAir;
    }

    public void setFrequencyOfTravelingByAir(String frequencyOfTravelingByAir) {
        this.frequencyOfTravelingByAir = frequencyOfTravelingByAir;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
