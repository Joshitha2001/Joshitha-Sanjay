package com.Carbonemission_BE.Repository;

import com.Carbonemission_BE.Entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AdminRepo extends JpaRepository<Admin,Integer> {
    Optional<Admin> findByEmail(String email);
}
