package com.Carbonemission_BE.Repository;

import com.Carbonemission_BE.Entity.CarbonDetails;
import com.Carbonemission_BE.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface CarbonDetailsRepo extends JpaRepository<CarbonDetails,Integer> {
    List<CarbonDetails> findByUserId(Integer id);


    List<CarbonDetails> findByUserIdOrderByDateAsc(Integer userId);

    List<CarbonDetails> findByUserAndDateBetween(User user, LocalDate start, LocalDate end);

    @Query("SELECT c FROM CarbonDetails c " +
            "WHERE c.user.id = :userId " +
            "AND c.date BETWEEN :startDate AND :endDate")
    List<CarbonDetails> findAllByUserIdAndMonth(
            @Param("userId") Integer userId,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate
    );

    @Query("SELECT c.user.id, SUM(c.carbonEmission) " +
            "FROM CarbonDetails c " +
            "WHERE MONTH(c.date) = MONTH(:currentDate) " +
            "AND YEAR(c.date) = YEAR(:currentDate) " +
            "GROUP BY c.user.id")
    List<Object[]> getTotalCarbonEmissionForCurrentMonth(LocalDate currentDate);



    List<CarbonDetails> findByUserIdAndDateBetween(int id, LocalDate start, LocalDate end);
}
