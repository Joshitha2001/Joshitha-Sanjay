package com.Carbonemission_BE.Service;

import com.Carbonemission_BE.Entity.CarbonDetails;
import com.Carbonemission_BE.Entity.User;
import com.Carbonemission_BE.Repository.CarbonDetailsRepo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.*;

@Service
public class GeminiService {

    @Value("${google.api.key}")
    private String apiKey;

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final CarbonDetailsRepo carbonDetailsRepository;

    public GeminiService(CarbonDetailsRepo carbonDetailsRepository) {
        this.carbonDetailsRepository = carbonDetailsRepository;
    }

    // Get previous month name
    private String getPreviousMonthName() {
        LocalDate prevMonth = LocalDate.now().minusMonths(1);
        return prevMonth.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
    }

    // Build user prompt
    private String buildPrompt(Map<String, Double> highCarbonFields) {
        String prevMonth = getPreviousMonthName();

        StringBuilder builder = new StringBuilder();
        builder.append("The following fields had the highest carbon emissions in ")
                .append(prevMonth).append(":\n");

        int i = 1;
        for (String field : highCarbonFields.keySet()) {
            builder.append(i++).append(". ").append(field).append("\n");
        }

        builder.append("\nFor EACH field above, generate a concise, actionable suggestion in 1–2 lines. ");
        builder.append("Format like:\n");
        builder.append("1. FieldName: Suggestion\n");
        builder.append("2. FieldName: Suggestion\n");
        builder.append("Do not skip fields.");

        return builder.toString();
    }

    // Parse AI suggestions "1. Field: suggestion"
    private List<Map<String, String>> extractFieldSuggestions(String text) {
        List<Map<String, String>> result = new ArrayList<>();
        String[] lines = text.split("\\r?\\n");

        for (String line : lines) {
            line = line.trim();
            if (!line.matches("^\\d+\\..*")) continue;

            int dotIndex = line.indexOf(".");
            String content = line.substring(dotIndex + 1).trim();
            int colonIdx = content.indexOf(":");

            if (colonIdx == -1) continue;

            String field = content.substring(0, colonIdx).trim();
            String suggestion = content.substring(colonIdx + 1).trim();

            result.add(Map.of("field", field, "suggestion", suggestion));
        }

        return result;
    }

    // Call Gemini 2.5 Flash model
    public List<Map<String, String>> getAISuggestions(Map<String, Double> highCarbonFields) {
        try {
            String prompt = buildPrompt(highCarbonFields);

            String url =
                    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey;

            // Correct JSON body
            String body = objectMapper.writeValueAsString(
                    Map.of(
                            "contents", List.of(
                                    Map.of("parts",
                                            List.of(Map.of("text", prompt)))
                            )
                    )
            );

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(body, headers);

            ResponseEntity<String> response =
                    restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

            JsonNode root = objectMapper.readTree(response.getBody());
            String aiText = root.at("/candidates/0/content/parts/0/text").asText("");

            List<Map<String, String>> parsed = extractFieldSuggestions(aiText);
            List<Map<String, String>> finalOutput = new ArrayList<>();

            for (String field : highCarbonFields.keySet()) {
                Optional<Map<String, String>> match =
                        parsed.stream().filter(m -> m.get("field").equalsIgnoreCase(field)).findFirst();

                finalOutput.add(Map.of(
                        "field", field,
                        "suggestion",
                        match.map(m -> m.get("suggestion"))
                                .orElse("No AI suggestion generated for this field.")
                ));
            }

            return finalOutput;

        } catch (Exception e) {
            e.printStackTrace();
            return List.of(Map.of("field", "AI Error", "suggestion", e.getMessage()));
        }
    }

    // Main logic: Identify top 3 high emission fields
    public List<Map<String, String>> getUserSuggestions(User user) {
        if (user == null) {
            return List.of(Map.of("field", "Error", "suggestion", "Invalid user"));
        }

        YearMonth prevMonth = YearMonth.now().minusMonths(1);
        LocalDate start = prevMonth.atDay(1);
        LocalDate end = prevMonth.atEndOfMonth();

        List<CarbonDetails> records =
                carbonDetailsRepository.findByUserAndDateBetween(user, start, end);

        if (records.isEmpty()) {
            return List.of(Map.of(
                    "field", "No Data",
                    "suggestion", "No carbon details recorded for previous month"
            ));
        }

        Map<String, Double> totals = new HashMap<>();

        for (CarbonDetails cd : records) {
            totals.merge("Heating", cd.getHeatingEnergySource() != null ? 1.0 : 0.0, Double::sum);
            totals.merge("Transport Mode", cd.getTransport() != null ? 1.0 : 0.0, Double::sum);
            totals.merge("Vehicle Distance (km)", cd.getVehicleDistanceKm() != null ? cd.getVehicleDistanceKm().doubleValue() : 0.0, Double::sum);
            totals.merge("Food Spending", cd.getGroceryBill() != null ? cd.getGroceryBill().doubleValue() : 0.0, Double::sum);
            totals.merge("Waste Bags", cd.getWasteBagCount() != null ? cd.getWasteBagCount().doubleValue() : 0.0, Double::sum);
            totals.merge("TV/PC Usage Hours", cd.getTvPcDailyHour() != null ? cd.getTvPcDailyHour().doubleValue() : 0.0, Double::sum);
            totals.merge("New Clothes Bought", cd.getNewClothes() != null ? cd.getNewClothes().doubleValue() : 0.0, Double::sum);
            totals.merge("Internet Usage Hours", cd.getInternetDailyHour() != null ? cd.getInternetDailyHour().doubleValue() : 0.0, Double::sum);
            totals.merge("Social Activity", cd.getSocialActivity() != null ? 1.0 : 0.0, Double::sum);
        }

        // Top 3
        LinkedHashMap<String, Double> sorted = new LinkedHashMap<>();
        totals.entrySet()
                .stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(3)
                .forEachOrdered(e -> sorted.put(e.getKey(), e.getValue()));

        return getAISuggestions(sorted);
    }

    // For debugging
    public void printAvailableModels() {
        try {
            String url = "https://generativelanguage.googleapis.com/v1beta/models?key=" + apiKey;

            ResponseEntity<String> response =
                    restTemplate.exchange(url, HttpMethod.GET, null, String.class);

            System.out.println("\n===== AVAILABLE MODELS =====");
            System.out.println(response.getBody());
            System.out.println("============================\n");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
