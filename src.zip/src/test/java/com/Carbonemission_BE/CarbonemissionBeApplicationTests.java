package com.Carbonemission_BE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarbonemissionBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
